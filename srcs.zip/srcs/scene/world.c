/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   world.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nryser <nryser@student.42lausanne.ch>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/18 19:56:22 by nryser            #+#    #+#             */
/*   Updated: 2025/04/18 19:56:22 by nryser           ###   ########.ch       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/minirt.h"
#include "engine.h"

t_world	*ft_world(void)
{
	t_world	*w;

	w = malloc(sizeof(t_world));
	if (!w)
		return (NULL);
	w->objects = NULL;
	w->object_count = 0;
	w->light = NULL;
	return (w);
}

t_world	*default_world(void)
{
	t_world		*w;
	t_sphere	*s1;
	t_sphere	*s2;
	t_matrix	*transform;
	w = ft_world();
	w->light = ft_light(ft_tuple(-10, 10, -10, POINT), ft_colour(1, 1, 1));
	s1 = ft_sphere(1);
	s1->base.m.c = ft_colour(1, 0, 0);
	s1->base.m.diffuse = 0.7;
	s1->base.m.specular = 0.2;
	s2 = ft_sphere(1);
	s2->base.m.c = ft_colour(0, 1, 0);
	//set_transf(s2, scale(0.5, 0.5, 0.5));
	transform= multiply_matrices(scale(1, 0.5, 0.5), translate(0, -2, 0));
	set_transf(s2, transform);
	w->objects = malloc(sizeof(t_sphere *) * 2);
	if (!w->objects)
		return (NULL);
	w->objects[0] = s1;
	w->objects[1] = s2;
	w->object_count = 2;
	return (w);
}

void	copy_hits(t_inters *dst, t_inters *src)
{
	t_hit	*hit;
	int		j;

	j = 0;
	while (j < src->count)
	{
		hit = src->hits[j];
		dst->hits[dst->count] = hit;
		dst->count++;
		j++;
	}
}

t_inters	*intersect_world(t_world *w, t_ray *r)
{
	t_inters	*xs;
	t_inters	*temp;
	int			i;

	xs = init_intersections(256);
	if (!xs)
		return (NULL);
	i = 0;
	while (i < w->object_count)
	{
		temp = intersect(w->objects[i], r);
		if (temp)
		{
			copy_hits(xs, temp);
			free(temp->hits);
			free(temp);
		}
		i++;
	}
	sort_intersections(xs->hits, xs->count);
	return (xs);
}
